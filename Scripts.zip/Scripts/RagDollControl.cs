using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.AI;

public class RagDollControl : MonoBehaviour
{
    private Animator animator;
    private NavMeshAgent agent;
    private Rigidbody[] rigidbodies;

    private void Awake() {
        animator = GetComponent<Animator>();
        agent = GetComponent<NavMeshAgent>();
        rigidbodies = GetComponentsInChildren<Rigidbody>();
        ActivateModeAnimated();
    }
    public void ActivateRagDoll() {
        if (agent != null) agent.enabled = false;
        if (animator != null) animator.enabled = false;

        Collider capsule = GetComponent<Collider>();
        if (capsule != null) capsule.enabled = false;

        foreach (Rigidbody rb in rigidbodies) {
            if (rb != null && rb != GetComponent<Rigidbody>()) {
                rb.isKinematic = false;
            }
        }
    }
    public void ActivateModeAnimated() {
        if (agent != null) agent.enabled=true;
        if (animator!= null) animator.enabled=true;

        foreach (Rigidbody rb in rigidbodies) {
            if (rb != null && rb != GetComponent<Rigidbody>()) { 
                rb.isKinematic=true;
            }
        
        }
    }
 }
