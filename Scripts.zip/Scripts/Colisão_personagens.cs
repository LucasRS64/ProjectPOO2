using UnityEngine;

public class Colisão_personagens : MonoBehaviour
{

    private IA_Boneco iaDoBoneco;
    void Start()
    {
        iaDoBoneco = GetComponentInParent<IA_Boneco>();
        if (iaDoBoneco == null) {
            iaDoBoneco = GetComponentInChildren<IA_Boneco>();
        }
            

        if (iaDoBoneco == null) {
            Debug.LogWarning("IA_Boneco não encontrado na hierarquia de " + gameObject.name);
        }

    }
    void OnCollisionEnter(Collision colisao) {
        if (iaDoBoneco != null && !iaDoBoneco.congelado && colisao.gameObject.CompareTag("Obstaculo")) {
            iaDoBoneco.Congelar();

        }
    }
}
