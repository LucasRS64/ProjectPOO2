using UnityEngine;
using TMPro;

public class Tempo : MonoBehaviour
{
    public TMP_Text textoTempo;
    public bool cont = true;
    public float tempoRes = 30f;


    void Update() {
        if (!cont) return;

        tempoRes -= Time.deltaTime;

        if (tempoRes <= 0f) {
            tempoRes= 0f;
            cont = false;

            FindObjectOfType<GerenciadorCena>().FinalizarSimulacaoAtual();
        }

        if (textoTempo != null)
            textoTempo.text = "Tempo: " + Mathf.CeilToInt(tempoRes).ToString() + "s";
    }
}

