using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.AI;

public class GerenciadorCena : MonoBehaviour
{
    public GameObject prefabObstac;
    public GameObject prefabPersonagens;

    public Transform paiPersonagens;
    public Transform paiObstaculos;

    
    public Transform areaCentroPersonagens;
    public Vector3 areaTamanhoPersonagens;

    public Transform areaCentroObstaculos;
    public Vector3 areaTamanhoObstaculos;

    public Transform[] rota1;
    public Transform[] rota2;
    public Transform[] rota3;
    public Transform[] rota4;

    private List<GameObject> personas = new List<GameObject>();
    private List<ConfigSimu> fila = new List<ConfigSimu>();
    private int simulacaoAtualIndex = 0;

    void Start()
    {
        LeitorDeArquivo();
        int layerPersonagem = LayerMask.NameToLayer("Personagem");
        Physics.IgnoreLayerCollision(layerPersonagem, layerPersonagem, true);
    }

    void IniciarPersonagens(int qtd) {
        List<GameObject> personagens = new List<GameObject>();

        for (int i = 0; i < qtd; i++) {
            Vector3 pos = GerarPosicaoAleatoria(areaCentroPersonagens.position, areaTamanhoPersonagens);

            NavMeshHit hit;
            if (NavMesh.SamplePosition(pos, out hit, 5f, NavMesh.AllAreas)) {
                pos = hit.position;
            }

            GameObject clone = Instantiate(prefabPersonagens, pos, Quaternion.identity, paiPersonagens);
            SetLayer(clone, LayerMask.NameToLayer("Personagem"));

            NavMeshAgent agent = clone.GetComponent<NavMeshAgent>();
            if (agent != null) {
                float variacao = Random.Range(-0.3f, 0.3f);
                agent.speed += variacao;
            }
            personagens.Add(clone);
            personagens.Add(clone);

            // Rolar D20
            int dado = Random.Range(1, 21);
            Transform[] rotaEscolhida = null;

            if (dado <= 10) {
                rotaEscolhida = (Random.value < 0.5f) ? rota1 : rota2;
                Debug.Log($"Personagem {i} tirou {dado} e vai para ROTA RUIM ({(rotaEscolhida == rota1 ? "rota1" : "rota2")})");
            }
            else {
                rotaEscolhida = (Random.value < 0.5f) ? rota3 : rota4;
                Debug.Log($"Personagem {i} tirou {dado} e vai para ROTA BOA ({(rotaEscolhida == rota3 ? "rota3" : "rota4")})");
            }

            if (rotaEscolhida == null || rotaEscolhida.Length == 0) {
                Debug.LogError($"Rota escolhida está nula ou vazia para personagem {i}");
            }

            // Enviar rota para o script de IA
            IA_Boneco ia = clone.GetComponent<IA_Boneco>();
            if (ia != null) {
                ia.InicializarRota(rotaEscolhida);
            }
        }

        // Ignorar colisões entre todos os personagens
        for (int i = 0; i < personagens.Count; i++) {
            for (int j = i + 1; j < personagens.Count; j++) {
                IgnorarColisaoEntre(personagens[i], personagens[j]);
            }
        }
        IgnorarCapsuleEntrePersonagens(personas);
    }




    void IniciarObstaculos(int qtd)
    {
        for (int i = 0; i < qtd; i++)
        {
            Vector3 pos = GerarPosicaoAleatoria(areaCentroObstaculos.position, areaTamanhoObstaculos);
            Instantiate(prefabObstac, pos, Quaternion.identity, paiObstaculos);
        }
    }

    Vector3 GerarPosicaoAleatoria(Vector3 centro, Vector3 tamanho)
    {
        return centro + new Vector3(
            Random.Range(-tamanho.x / 2f, tamanho.x / 2f),
            Random.Range(-tamanho.y / 2f, tamanho.y / 2f),
            Random.Range(-tamanho.z / 2f, tamanho.z / 2f)
        );
    }

    void LeitorDeArquivo()
    {
        string caminho = Path.Combine(Application.streamingAssetsPath, "Entrada.txt");

        if (File.Exists(caminho))
        {
            string[] blocos = File.ReadAllText(caminho).Split(new string[] { "------------" }, System.StringSplitOptions.RemoveEmptyEntries);
            

            foreach (string bloco in blocos)
            {
                string[] lines = bloco.Split('\n');
                ConfigSimu config = new ConfigSimu();

                foreach (string line in lines) {
                    string clean = line.Trim().ToLower();
                    if (clean.StartsWith("personagens=")) {
                        int.TryParse(clean.Substring(12), out config.personagens);
                    }
                    else if (clean.StartsWith("obstaculos=")) {
                        int.TryParse(clean.Substring(11), out config.obstaculos);
                    }
                    else if (clean.StartsWith("tempo=")) {
                        float.TryParse(clean.Substring(6), out config.tempo);
                    }
                }

                fila.Add(config);
                
            }


            StartCoroutine(RodarSimulacoes());
        }
        else
        {
            Debug.LogError("Arquivo não encontrado! em: " + caminho);
        }
    }

    void SetLayer(GameObject obj, int layer) {
        obj.layer = layer;
        foreach (Transform child in obj.transform) { 
            SetLayer(child.gameObject, layer);
        }
    }

    void IgnorarColisaoEntre(GameObject a, GameObject b) {
        Collider[] collidersA = a.GetComponentsInChildren<Collider>();
        Collider[] collidersB = b.GetComponentsInChildren<Collider>();

        foreach (var colA in collidersA) {
            foreach (var colB in collidersB) {
                Physics.IgnoreCollision(colA, colB);
            }
        }
    }

    void IgnorarCapsuleEntrePersonagens(List<GameObject> personas) {
        for (int i = 0; i < personas.Count; i++) {
            Collider colA = personas[i].GetComponent<Collider>(); 
            for (int j = i + 1; j < personas.Count; j++) {
                Collider colB = personas[j].GetComponent<Collider>();
                if (colA != null && colB != null)
                    Physics.IgnoreCollision(colA, colB);
            }
        }
    }

    IEnumerator RodarSimulacoes() {
        while (simulacaoAtualIndex < fila.Count) { 
            var sim = fila[simulacaoAtualIndex];

            IniciarPersonagens(sim.personagens);
            IniciarObstaculos(sim.obstaculos);

            var hud = FindObjectOfType<Tempo>();
            if (hud != null) {
                hud.tempoRes = sim.tempo;
                hud.cont = true;
            
            }

            yield return new WaitForSeconds(sim.tempo);

            FinalizarSimulacaoAtual();
            simulacaoAtualIndex++;
        }

        Application.Quit();
    }

    public void FinalizarSimulacaoAtual() {
        foreach (Transform filho in paiPersonagens) Destroy(filho.gameObject);
        foreach (Transform filho in paiObstaculos) Destroy(filho.gameObject);
    }


    private void OnDrawGizmosSelected()
    {
        if (areaCentroPersonagens != null)
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawWireCube(areaCentroPersonagens.position, areaTamanhoPersonagens);
        }

        if (areaCentroObstaculos != null)
        {
            Gizmos.color = Color.magenta;
            Gizmos.DrawWireCube(areaCentroObstaculos.position, areaTamanhoObstaculos);
        }
    }
}

