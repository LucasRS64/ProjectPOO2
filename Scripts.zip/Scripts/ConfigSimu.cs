using UnityEngine;

public class ConfigSimu : MonoBehaviour
{
    public int personagens;
    public int obstaculos;
    public float tempo;

}
