using UnityEngine;

public class AnimadorBoneco : MonoBehaviour
{
    private Animator controladorDePersonagem;

    void Start()
    {
        controladorDePersonagem = GetComponent<Animator>();
    }
    public void AtualizarAnimacaoMovimento(bool estaAndando)
    {
        controladorDePersonagem.SetBool("Walking", estaAndando);
    }
}

