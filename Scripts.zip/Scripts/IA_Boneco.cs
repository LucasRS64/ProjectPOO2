﻿using UnityEngine;
using UnityEngine.AI;

public class IA_Boneco : MonoBehaviour {
    private AnimadorBoneco controladorDePersonagem;
    public float minimumDistance = 1.5f;

    public Transform[] patrol;

    private int indexAtual = 0;
    private NavMeshAgent agent;
    public bool congelado;

    void Start() {

        controladorDePersonagem = GetComponent<AnimadorBoneco>();
        agent = GetComponent<NavMeshAgent>();
        agent.obstacleAvoidanceType = ObstacleAvoidanceType.NoObstacleAvoidance;
        agent.avoidancePriority = Random.Range(0, 100);
    }

    void Update() {
        if (congelado || agent == null || !agent.isOnNavMesh) {
            if (agent != null && agent.isOnNavMesh)
                agent.isStopped = true;
            return;
        }
            bool andando = agent.velocity.magnitude > 0.1f;
        if (controladorDePersonagem != null)
            controladorDePersonagem.AtualizarAnimacaoMovimento(andando);

        if (!agent.pathPending && (!agent.hasPath || agent.remainingDistance <= minimumDistance)) {
            if (patrol != null && patrol.Length > 0) {
                if (indexAtual < patrol.Length - 1) {
                    indexAtual++;
                    SetProximoPonto();
                }
                else {
                    agent.isStopped = true;
                    controladorDePersonagem.AtualizarAnimacaoMovimento(false);
                }
            }
            else {
                Debug.LogWarning($"[{gameObject.name}] Nenhum ponto de patrulha definido.");
            }
        }

        Vector3 localVelocity = transform.InverseTransformDirection(agent.velocity.normalized);
        GetComponent<Animator>().SetFloat("Horizontal", localVelocity.x);
        GetComponent<Animator>().SetFloat("Vertical", localVelocity.z);
    }

    public void SetProximoPonto() {
        if (patrol != null && patrol.Length > 0 && agent.isOnNavMesh) {
            agent.SetDestination(patrol[indexAtual].position);
        }
    }

    public void Congelar() {
        congelado = true;

        if (agent != null) agent.isStopped = true;
        if (controladorDePersonagem != null)
            controladorDePersonagem.AtualizarAnimacaoMovimento(false);

        
        RagDollControl ragdoll = GetComponent<RagDollControl>();
        if (ragdoll != null)
            ragdoll.ActivateRagDoll();
    }

    public void InicializarRota(Transform[] rota) {
        patrol = rota;
        indexAtual = 0;
        if (agent == null)
            agent = GetComponent<NavMeshAgent>();

        if (patrol != null && patrol.Length > 0 && agent.isOnNavMesh) {
            agent.SetDestination(patrol[indexAtual].position);
            Debug.Log($"{gameObject.name} recebeu {patrol.Length} pontos e iniciou a patrulha.");
        }
        else {
            Debug.LogError($"[{gameObject.name}] rota inválida ou agente fora do NavMesh.");
        }
    }
}

