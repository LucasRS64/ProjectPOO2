using UnityEngine;

public class CameraLivre : MonoBehaviour
{
    public bool followTarget = true;
    public float sense = 2f;
    public Transform target;
    public Vector3 offset = new Vector3(0, 3, 5);
    public float moveSpeed = 100f;

    private float rotX = 0f;
    private float rotY = 0f;
    
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void Update()
    {

        if (Input.GetKeyDown(KeyCode.L))
        {
            followTarget = !followTarget;
        }

        rotX -= Input.GetAxis("Mouse Y") * sense;
        rotY += Input.GetAxis("Mouse X") * sense;
        rotX = Mathf.Clamp(rotX, -60f, 60f);

        Quaternion rotation = Quaternion.Euler(rotX, rotY, 0);
        transform.rotation = rotation;


        if (followTarget && target != null) 
        {
            transform.position = target.position + rotation * offset;

        }
        else {
            float h = Input.GetAxis("Horizontal");
            float v = Input.GetAxis("Vertical"); 
            float upDown = 0f;

            if (Input.GetKey(KeyCode.E)) upDown += 1f;
            if (Input.GetKey(KeyCode.Q)) upDown -= 1f;

            Vector3 direction = transform.right * h + transform.forward * v + transform.up * upDown;
            transform.position += direction * moveSpeed * Time.deltaTime;
        }
    }
}
